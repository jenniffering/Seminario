/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import com.google.gson.Gson;
import com.seminario.cliente.Pedido;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.ConvertirUtil;
import modelo.Moneda;

/**
 *
 * @author Svenk .D Amsel
 */
public class ConvertirServlet extends HttpServlet {

    @PersistenceContext(unitName = "com.seminario_ConvertidorMoneda_war_1.0-SNAPSHOTPU")
    private EntityManager em;
    @Resource
    private javax.transaction.UserTransaction utx;
    private EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.seminario_ConvertidorMoneda_war_1.0-SNAPSHOTPU");
    private MonedaJpaController js=new MonedaJpaController(utx, emf);
    private ConvertirUtil forex = new ConvertirUtil();
    Gson gson = new Gson();

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
         PrintWriter out = response.getWriter();
        try{
            /* TODO output your page here. You may use following sample code. */
            String ac=request.getParameter("accion");
            String pc=request.getParameter("pc");
              System.out.println(pc);
              System.out.println(ac);
            if(ac!=null){
                if(ac.equals("convertir")){                
                    forex.setMonedas(js.findMonedaEntities());
                    String result = forex.convertir(request.getParameter("actual"), request.getParameter("objetivo"), request.getParameter("valor"))+" "+ request.getParameter("objetivo");                                 
                    request.getSession().setAttribute("monedas.result", result);
                    response.sendRedirect("cambio.jsp");
                }
                if(ac.equals("inicio")&&ac!=null){
                    request.getSession().setAttribute("monedas.lista", js.findMonedaEntities());
                    response.sendRedirect("cambio.jsp");
                }if(ac.equals("limpiar")&&ac!=null){
                    request.getSession().setAttribute("monedas.result", "");
                    response.sendRedirect("cambio.jsp");
                }
            }
            if(pc!=null){
                forex.setMonedas(js.findMonedaEntities());
                String json=request.getParameter("pc");
                System.out.println(json);
                Pedido nuevo= gson.fromJson(json, Pedido.class);
                String result = gson.toJson(forex.convertir(nuevo.getActual(),nuevo.getObjetivo(), nuevo.getValor())+" "+nuevo.getObjetivo());
                
                System.out.println(result);
                response.setContentType("application/json");
                response.setCharacterEncoding("UTF-8");
                PrintWriter salida = response.getWriter() ;
                salida.print(result);                
                salida.close();
                
            }
            
        }catch (Exception ex) {
            Logger.getLogger(ConvertirServlet.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        
        processRequest(request, response);
        
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {        
        processRequest(request, response);
        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    public void persist(Object object) {
        try {
            utx.begin();
            em.persist(object);
            utx.commit();
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e);
        }
    }

}
