/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.List;


/**
 *
 * @author Svenk .D Amsel
 */
public class ConvertirUtil {
    
    private List<Moneda>monedas;
    
    public String convertir(String actual, String objetivo, String valor){
        if(actual.equals("USD")){
            return FromUSD(valor,objetivo);
        }else if(!actual.equals("USD")&&objetivo.equals("USD")){
            return toUSD(valor,actual);
        }else if(!actual.equals("USD")&& !objetivo.equals("USD")){
            return FromTo(valor, objetivo, actual);
        }else{
            return valor;
        }
    }

    private String FromUSD(String valor, String objetivo) {
        float actual = Float.parseFloat(valor);
        float result=actual;
        for(int i =0; i<monedas.size();i++){
            if (monedas.get(i).getNombre().equals(objetivo)){
                result=monedas.get(i).getValorDolares()*actual;
            }
        }        
        return Float.toString(result);
    }

    private String toUSD(String valor, String objetivo) {
        float actual = Float.parseFloat(valor);
        float result=actual;
        for(int i =0; i<monedas.size();i++){
            if (monedas.get(i).getNombre().equals(objetivo)){
                result=actual/monedas.get(i).getValorDolares();
            }
        }        
        return Float.toString(result);
    }

    private String FromTo(String valor, String objetivo, String actual) {
        valor=toUSD(valor,actual);
        return FromUSD(valor,objetivo);
        
    }

    public List<Moneda> getMonedas() {
        return monedas;
    }

    public void setMonedas(List<Moneda> monedas) {
        this.monedas = monedas;
    }
    
}
